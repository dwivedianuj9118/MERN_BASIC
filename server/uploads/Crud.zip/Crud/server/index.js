import express from "express";
import { MongoClient, ObjectId } from "mongodb";
import cors from "cors";

const app = express(); // Create Express app server
app.use(cors());
app.use(express.json());

const uri = "mongodb://localhost:27017/";
const client = new MongoClient(uri);

let collection;

// 🔌 Connect to MongoDB
async function connectDB() {
  try {
    await client.connect();
    const db = client.db("testDB"); // your database name
    collection = db.collection("contact"); // your collection name
    console.log("✅ MongoDB connected");
  } catch (err) {
    console.error("❌ DB connection failed:", err);
  }
}

await connectDB();


// ====================
// 🔹 CRUD API ROUTES 🔹
// ====================

app.get("/", (req, res) => {
    const r = req.params;
  res.send(`Welcome to the User API ${JSON.stringify(r)}`);
});

// 📄 GET all users
app.get("/api/users", async (req, res) => {
  const users = await collection.find().toArray();
  res.json(users);
});

// ➕ POST create new user
app.post("/api/users", async (req, res) => {
  const result = await collection.insertOne(req.body);
  res.json(result);
});

app.post("/api/savecontact", async (req, res) => {
  const result = await collection.insertOne(req.body);
  res.json(result);
});
app.get("/api/getcontacts", async (req, res) => {
  const users = await collection.find().toArray();
  res.json(users);
});

// 📝 PUT update user by ID
app.put("/api/users/:id", async (req, res) => {
  const { id } = req.params;
  console.log(id, req.body);
  const updated = await collection.updateOne(
    { _id: new ObjectId(id) },
    { $set: req.body }
  );
  res.json(updated);
});

// ❌ DELETE user by ID
app.delete("/api/users/:id", async (req, res) => {
  const { id } = req.params;
  const deleted = await collection.deleteOne({ _id: new ObjectId(id) });
  res.json(deleted);
});



// ✅ Server start
const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
