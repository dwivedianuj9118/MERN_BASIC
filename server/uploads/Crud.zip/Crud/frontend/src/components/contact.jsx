

import axios from 'axios';
import React, { useEffect, useState } from 'react';


function Contact() {
    const [contact, setContact] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:3000/api/getcontacts")
            .then((res) => {
                setContact(res.data);
            })
            .catch((err) => {
                console.log("Error fetching contacts:", err);
            });
    }, [contact]);
    return (
        <div className="bg-gradient-to-tr from-[#EEAECA] to-[#94BBE9] shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
            <ul role="list" className="divide-y divide-white/5">

                {
                    contact.map((c) => (
                    <li className="flex justify-between">
                        <div className="flex min-w-0 gap-x-4">
                            <div className="min-w-0 flex-auto">
                                <p className="text-sm/6 font-semibold text-white">{c.firstName}-{c.lastName}</p>
                               
                            </div>
                            <div className="hidden sm:flex sm:flex-col sm:items-end">
                                <p className="text-sm/6 text-white">{c.email}</p>
                               
                            </div>
                            <div className="hidden sm:flex sm:flex-col sm:items-end">
                                <p className="text-sm/6 text-white">{c.phoneNumber}</p>
                               
                            </div>
                        </div>
                    
                    </li>
                    ))
                }


        </ul>
        </div >
    );
}
export default Contact;