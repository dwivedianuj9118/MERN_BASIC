import Contact from "./components/contact.jsx";
import Home from "./components/Home.jsx";
import Register from "./components/Register.jsx";
import { Routes, Route } from "react-router-dom";
function App() {


  return (
    <>
      
      <Routes >
        <Route path="/" element={<Home />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/register" element={<Register />} />
      </Routes>
    </>
  )
}

export default App
